A=bestA;
B=bestB;