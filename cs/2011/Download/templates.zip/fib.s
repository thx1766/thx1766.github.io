	.file	"fib.c"
	.text
.globl fib
	.type	fib, @function
fib:
	pushl	%ebp
	movl	%esp, %ebp
	movl	8(%ebp), %eax
	addl	%eax, %eax
	popl	%ebp
	ret
	.size	fib, .-fib
	.ident	"GCC: (Ubuntu 4.4.3-4ubuntu5) 4.4.3"
	.section	.note.GNU-stack,"",@progbits
