.globl sumInts
	.type	sumInts, @function
sumInts:
	#place your code for sumInts here
