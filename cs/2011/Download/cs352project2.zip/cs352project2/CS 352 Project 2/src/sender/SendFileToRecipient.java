package sender;

public class SendFileToRecipient extends Thread{
	int portnumber = 3101;
	int packetsize = 1024;
	int windowsize = 10;
	private java.net.InetAddress target;
	private java.util.ArrayList<java.net.DatagramPacket> data;
	
	//multiple constructors (flexible code reuse without too much editing), fewer parameters means using more "default" values
	public void sendFileToRecipient(java.net.InetAddress address, java.util.ArrayList<java.net.DatagramPacket> packets, int portnum, int packsize, int winsize){
		target = address;
		data = packets;
		portnumber = portnum;
		packetsize = packsize;
		windowsize = winsize;
	}
	public void sendFileToRecipient(java.net.InetAddress address, java.util.ArrayList<java.net.DatagramPacket> packets, int portnum, int packsize){
		target = address;
		data = packets;
		portnumber = portnum;
		packetsize = packsize;
	}
	public void sendFileToRecipient(java.net.InetAddress address, java.util.ArrayList<java.net.DatagramPacket> packets, int portnum){
		target = address;
		data = packets;
		portnumber = portnum;
	}
	public void sendFileToRecipient(java.net.InetAddress address, java.util.ArrayList<java.net.DatagramPacket> packets){
		target = address;
		data = packets;
	}
	
	
	public void run(){
		try{
			int sequencenumber = 0;
			SendPacketToRecipient thread1 = new SendPacketToRecipient(sequencenumber, target, data, portnumber);
			//public void SendPacketToRecipient(int seqnum, java.net.InetAddress tar, java.util.ArrayList<java.net.DatagramPacket> data, int port){
			//start thread for receiving ACK's
			//start thread for each packet we want to send in our initial window
			//while(true){
				//try{
				//transmit packet
				//sleep
				//}catch(java.lang.InterruptedException e){
				//thread was interrupted by receipt of ACK, dies
				//this.interrupt();
				//}
			//}
			Thread.sleep(100);
		}catch(java.lang.InterruptedException e){
			
		}
	
	}

	public void send(java.net.DatagramPacket packet, java.net.InetAddress ip, int port) throws java.io.IOException{
		java.net.DatagramSocket mysocket = new java.net.DatagramSocket();
		java.net.DatagramPacket addressedpacket = packet;
		addressedpacket.setAddress(ip);
		mysocket.send(addressedpacket);
		byte[] receivedata = new byte[packetsize];
		java.net.DatagramPacket receivepacket = new java.net.DatagramPacket(receivedata, packetsize);
		mysocket.receive(receivepacket);
	}
}