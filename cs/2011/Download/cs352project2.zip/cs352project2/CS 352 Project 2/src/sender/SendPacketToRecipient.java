package sender;

import java.net.SocketException;

public class SendPacketToRecipient extends Thread{
int packetsequencenumber = 0;
java.net.DatagramPacket mypacket;
java.net.DatagramSocket mysocket;
java.net.InetAddress target;
int port;
public void SendPacketToRecipient(int seqnum, java.net.InetAddress tar, java.util.ArrayList<java.net.DatagramPacket> data, int port){
	target = tar;
	mypacket = data.get(packetsequencenumber);
	try {
		mysocket = new java.net.DatagramSocket(port, target);
	} catch (java.net.SocketException e) {
		e.printStackTrace();
	}
}
public void run(){
	try{
		mysocket.send(mypacket);
		Thread.sleep(100);
	}catch(java.lang.InterruptedException e){
		this.interrupt();
	}catch(java.io.IOException e){
		e.printStackTrace();
}
}
}
