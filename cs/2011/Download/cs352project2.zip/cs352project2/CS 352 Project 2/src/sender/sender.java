package sender;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;


/*
 * Sends to minimum three max five destinations.
 * 		hardcode ip addresses
 * 		set in beginning (prompt)
 * 
 * must take command line argument for percentage of packets to lose
 */

public class sender {
	
	static int droppercentage = 0;

	static int portnumber = 3101;
	//ports 3100 to 3120 can be used
	
	static int packetsize = 1024;
	
	
	
	static void main(String args[]){
		droppercentage = (int) new java.lang.Integer((args[0]));
	
		java.io.BufferedReader reader =new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
		
		java.net.InetAddress recieve1=null;
		java.net.InetAddress recieve2=null;
		java.net.InetAddress recieve3=null;
		java.net.InetAddress recieve4=null;
		java.net.InetAddress recieve5=null;
		
		try{
		recieve1 = java.net.InetAddress.getByName("192.168.1.10");
		recieve2 = java.net.InetAddress.getByName("192.168.1.11");
		recieve3 = java.net.InetAddress.getByName("192.168.1.12");
		recieve4 = java.net.InetAddress.getByName("192.168.1.13");
		recieve5 = java.net.InetAddress.getByName("192.168.1.14");
		}catch(java.net.UnknownHostException e){
			System.out.println("UnknownHostException in one of your specified target addresses - aborting");
			return;
		}
		
		System.out.println("Path of file to send:");
		String path = null;
		try{
		path = reader.readLine();
		}catch(java.io.IOException e){
			System.out.println("IOException reading input - aborting");
			return;
		}
		
		java.io.FileInputStream data=null;
		try{
			data = new java.io.FileInputStream(path);	
		}catch(java.io.FileNotFoundException e){
			System.out.println("File not found - aborting.");
			return;
		}

		System.out.println("Breaking file into packets...");
		
		java.util.ArrayList<java.net.DatagramPacket> packets = new java.util.ArrayList<DatagramPacket>();
		
		try{
			while(data.available() != -1){
				byte[] temp = new byte[packetsize];
				int bytes_copied = data.read(temp);
				//java.net.DatagramPacket newpacket = new java.net.DatagramPacket(temp,packetsize,null,portnumber);
				//packets.add(newpacket);
				packets.add(new java.net.DatagramPacket(temp,packetsize,null,portnumber));
			}
		}catch(java.io.IOException e){
			System.out.println("IOException when trying to read from file - aborting.");
			return;
		}

		System.out.println(
				"Sending file:\n\t"
				+path+
				"\nto recipients:\n\t"
				+recieve1.toString()+", \n\t"
				+recieve2.toString()+", \n\t"
				+recieve3.toString()+", \n\t"
				+recieve4.toString()+", \n\t"
				+recieve5.toString()+"\n"
				+"working...");

		//start threads for sending to each host

		/*
		 Runnable r = new SendFileToRecipient();
		 Thread t = new Thread(r);
		 t.start();
		 * 
		 */
		
		
		/*
		
		if(sendFile(recieve1, packets)){
			System.out.println("Sent succesfully to"+recieve1.toString());
		}else{
			System.out.println("Send to "+recieve1.toString()+" failed.");
		}
		if(sendFile(recieve2, packets)){
			System.out.println("Sent succesfully to"+recieve2.toString());
		}else{
			System.out.println("Send to "+recieve2.toString()+" failed.");
		}
		if(sendFile(recieve3, packets)){
			System.out.println("Sent succesfully to"+recieve3.toString());
		}else{
			System.out.println("Send to "+recieve3.toString()+" failed.");
		}
		if(sendFile(recieve4, packets)){
			System.out.println("Sent succesfully to"+recieve4.toString());
		}else{
			System.out.println("Send to "+recieve4.toString()+" failed.");
		}
		if(sendFile(recieve5, packets)){
			System.out.println("Sent succesfully to"+recieve5.toString());
		}else{
			System.out.println("Send to "+recieve5.toString()+" failed.");
		}
		*/
	}
	
	public static boolean sendFile(java.net.InetAddress address, java.util.ArrayList<java.net.DatagramPacket> list){
		int index = 0;
		while(!list.isEmpty()){
			java.net.DatagramSocket socket;
			try {
				socket = new java.net.DatagramSocket(portnumber, address);
			} catch (SocketException e) {
				System.out.println("SocketException - aborting");
				return false;
			}
			try {
				socket.send(list.get(index));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			index++;
			break;
		}
		return true;
	}

}
