package reciever;

public class reciever {

	int droppercentage = 0;
	
	public void main(String args[]){
		droppercentage = ((int) new java.lang.Integer((args[0])));
	}
	
}
