package traceroutestandard;

import java.io.*;
import java.math.BigInteger;
import java.net.*;

/*
 * 	//goal of project: implement traceroute
	//special case: we must use a voslab machine as a "virtual router" to create packets for us
	//				192.168.51.117 port 3000 - accepts network messages as payload of UDP packet
	//command line argument: ip address of destination machine
	//talking to voslab server:
				//construct information that would otherwise be IP header and ICMP header
				//java class NetworkMessage will contain public methods for IP header and ICMP header classes
				//classes will have just public data members, no methods
				//fill in atomic fields of IP header and ICMP header objects, concatenate them, make it payload of UDP packet
				//server creates network-level message, sends it, recieves ICMP response, constructs NetworkMessage as response
	//I am responsible for:
	//figuring out how to send and recieve UDP packets
	//filling in the fields of the IP header and ICMP header class instances
	//interpreting the fields of the IP header and ICMP header.
	//finding the right Java classes (e.g InetAddress et al) to deal with IP addresses.
 */

public class traceroute {
	public static void main(String args[]){
		String ipaddress = args[0];
		InetAddress target=null, serveraddress=null, gotback = null;
		byte time_to_live =0;
		try {
			target = InetAddress.getByName(ipaddress);
		} catch (UnknownHostException e1) {
			System.out.println("The provided address resulted in an UnknownHostException"); return;}
		try {
			serveraddress = InetAddress.getByName("192.168.51.117");
		} catch (UnknownHostException e1) {
			System.out.println("The server address is invalid. This is hardcoded, so the code needs to be edited to fix."); return;}
		try {
			gotback = InetAddress.getByName("0.0.0.0");
		} catch (UnknownHostException e1) {
			System.out.println("Invalid remote address. Details: InetAddress.getByName("+gotback+") threw an UnknownHostException: ");
			e1.printStackTrace();
		}
System.out.println("Traceroute to "+target+" 30 hops max (hardcoded)");
int count = 0;		
int intsrc = 0, intdest=0;

byte[] bytesrc = serveraddress.getAddress();
//intsrc+=(int) bytesrc[0]; intsrc+=(int) bytesrc[1]; intsrc+=(int) bytesrc[2]; intsrc+=(int) bytesrc[3];
intsrc+=(int) bytesrc[3]; intsrc+=(int) bytesrc[2]; intsrc+=(int) bytesrc[1]; intsrc+=(int) bytesrc[0];
byte[] bytedest = target.getAddress();
intdest+=(int) bytedest[0]; intdest+=(int) bytedest[1]; intdest+=(int) bytedest[2]; intdest+=(int) bytedest[3];
//intdest+=(int) bytedest[3]; intdest+=(int) bytedest[2]; intdest+=(int) bytedest[1]; intdest+=(int) bytedest[0];

while(!target.equals(gotback)){
			NetworkMessage netmsg = makenetmessage(time_to_live, intsrc, intdest);
			byte[] datafromserver=null;
			try {
				datafromserver = sendrecieve(netmsg);
//for(int a=0; a<datafromserver.length;a++)
//	System.out.print(datafromserver[a]+" ");
//System.out.println();
			} catch (Exception e) {
				System.out.println("sendrecieve() failed");
				e.printStackTrace();
			}
			String responseip = "empty";
			
NetworkMessage responsenetmsg = new NetworkMessage();			
try {responsenetmsg.set(datafromserver);} catch (IOException e) {e.printStackTrace();}

try {
	byte[] bytes = BigInteger.valueOf(responsenetmsg.ipHeader.saddr).toByteArray();
	byte[] arraybytes = new byte[4];
	if (bytes.length == 5){
		arraybytes[0]=bytes[1];
		arraybytes[1]=bytes[2];
		arraybytes[2]=bytes[3];
		arraybytes[3]=bytes[4];
	}else{
		arraybytes[0]=bytes[0];
		arraybytes[1]=bytes[1];
		arraybytes[2]=bytes[2];
		arraybytes[3]=bytes[3];
	}
		gotback = InetAddress.getByAddress(arraybytes);
	//gotback = InetAddress.getByAddress(BigInteger.valueOf(responsenetmsg.ipHeader.saddr).toByteArray());
	//System.out.println("gotback: "+gotback);
} catch (UnknownHostException e1) {e1.printStackTrace();}

int dest = responsenetmsg.ipHeader.daddr;
int src = responsenetmsg.ipHeader.saddr;

InetAddress responsesipa=null, responsedipa=null;


try{
	byte[] bytes = BigInteger.valueOf(responsenetmsg.ipHeader.saddr).toByteArray();
	byte[] arraybytes = new byte[4];
	if (bytes.length == 5){
		arraybytes[0]=bytes[1];
		arraybytes[1]=bytes[2];
		arraybytes[2]=bytes[3];
		arraybytes[3]=bytes[4];
//		System.out.println("negative");
	}else{
		arraybytes[0]=bytes[0];
		arraybytes[1]=bytes[1];
		arraybytes[2]=bytes[2];
		arraybytes[3]=bytes[3];
//		System.out.println("not negative");
	}
	responsesipa = InetAddress.getByAddress(arraybytes);
 //responsesipa = InetAddress.getByAddress(BigInteger.valueOf(src).toByteArray());
}catch(Exception e){
	System.out.println("something went wrong with src");
}
try{
	byte[] bytes = BigInteger.valueOf(responsenetmsg.ipHeader.daddr).toByteArray();
	byte[] arraybytes = new byte[4];
	if (bytes.length == 5){
		arraybytes[0]=bytes[4];
		arraybytes[1]=bytes[3];
		arraybytes[2]=bytes[2];
		arraybytes[3]=bytes[1];
//		System.out.println("negative");
	}else{
		arraybytes[0]=bytes[3];
		arraybytes[1]=bytes[2];
		arraybytes[2]=bytes[1];
		arraybytes[3]=bytes[0];
//		System.out.println("not negative");
	}
	responsedipa = InetAddress.getByAddress(arraybytes);
	 //responsedipa = InetAddress.getByAddress(BigInteger.valueOf(dest).toByteArray());
	}catch(Exception e){
		System.out.println("something went wrong with dest");
	}

//responseip = "\nd: "+responsedipa+" s: "+responsesipa+"\nType: "+responsenetmsg.icmpHdr.code+"Code: "+responsenetmsg.icmpHdr.type;
responseip = gotback.toString();
			System.out.println(time_to_live+": "+responseip);
			time_to_live++;
			count++;
			if (count>30)
				break;
		}
	}
	public static IPheader makeipheader(byte ttl, byte id, int source, int dest){
		IPheader rd = new IPheader();//return data
		rd.ihl = 0x5;
		rd.version = 0x4;
		rd.tos = 0x0;
		rd.flags = 0x0;
		rd.ttl = ttl;
		rd.protocol = 0x1;
		rd.tot_len = 60;
		rd.id = id;
		rd.frag_off = 0x0;
		rd.checksum = 0x0;
		rd.saddr = source;
		rd.daddr = dest;
		return rd;
	}
	public static IcmpHdr makeicmpheader(){
		IcmpHdr returndata = new IcmpHdr();
		returndata.type = 0x8;
		returndata.code = 0x0;
		returndata.checksum =0x0;
		returndata.id = 0x0;
		returndata.sequence=0x0;
		return returndata;
	}
	public static NetworkMessage makenetmessage(byte ttl, int source, int dest){
		NetworkMessage returndata = new NetworkMessage();
		returndata.ipHeader.ihl = 0x5;
		returndata.ipHeader.version = 0x4;
		returndata.ipHeader.tos = 0x0;
		returndata.ipHeader.flags = 0x0;
		returndata.ipHeader.ttl = ttl;
		returndata.ipHeader.protocol = 0x1;
		returndata.ipHeader.tot_len = 60;
		returndata.ipHeader.id = 0x0;
		returndata.ipHeader.frag_off = 0x0;
		returndata.ipHeader.checksum = 0x0;
		returndata.ipHeader.saddr = source;
		returndata.ipHeader.daddr = dest;
		returndata.icmpHdr.type = 0x8;
		returndata.icmpHdr.code = 0x0;
		returndata.icmpHdr.checksum = 0x0;
		returndata.icmpHdr.id = 0x0;
		returndata.icmpHdr.sequence = 0x0;
		return returndata;
	}
	public static byte[] sendrecieve(NetworkMessage netmessage){
		try{
		DatagramSocket mysocket = new DatagramSocket();
		DatagramPacket mypacket = new DatagramPacket(netmessage.getBytes(), netmessage.getBytes().toString().length(), InetAddress.getByName("192.168.51.117"), 3000);
		mysocket.send(mypacket);
		byte[] recievemessage=new byte[100];
		DatagramPacket serverpacket = new DatagramPacket(recievemessage,recievemessage.length);
		mysocket.receive(serverpacket);
		return recievemessage;
		}catch (Exception e){
			e.printStackTrace();
		}
		return null;
	}

	public static InetAddress talkToServer(NetworkMessage netmessage){
		//method now defunct - never worked properly
		try{
		DatagramSocket mysocket = new DatagramSocket();
		DatagramPacket mypacket = new DatagramPacket(netmessage.getBytes(), netmessage.getBytes().toString().length(), InetAddress.getByName("192.168.51.117"), 3000);
System.out.println("network message contents:");
byte[] bytesfrommypacket = netmessage.getBytes();
int i2=0;
while(i2<bytesfrommypacket.length){
	System.out.println(bytesfrommypacket[i2]);
	i2++;
}
System.out.println("about to send packet");
		mysocket.send(mypacket);
System.out.println("message sent to server");		
		byte[] recievemessage=new byte[30];
		//DatagramPacket serverpacket = new DatagramPacket(recievemessage,recievemessage.toString().length());
		DatagramPacket serverpacket = new DatagramPacket(recievemessage,recievemessage.length);
System.out.println("about to recieve packet");		
		mysocket.receive(serverpacket);
System.out.println("message recieved back from server");
byte[] bytesfrompacket = serverpacket.getData();
int i=0;
while(i<bytesfrompacket.length){
	System.out.println(bytesfrompacket[i]);
	i++;
}
System.out.println(serverpacket.toString());
		NetworkMessage servernetworkmessage = new NetworkMessage();
		servernetworkmessage.set(serverpacket.getData());
		mysocket.close();
		//return servernetworkmessage;
		//IcmpHdr responseicmp = servernetworkmessage.icmpHdr;
		//IPheader responseip = servernetworkmessage.ipHeader;
		//String responseipstring = ((Integer)responseip.saddr).toString();
		//InetAddress returndata = InetAddress.getByAddress(BigInteger.valueOf(responseip.saddr).toByteArray());
		//return returndata;
		return InetAddress.getByAddress(BigInteger.valueOf(servernetworkmessage.ipHeader.saddr).toByteArray());
		}catch(IOException e){
			e.printStackTrace();
		}
		return null;
	}
	public static InetAddress talkToServer(IPheader ipheader, IcmpHdr icmpheader) throws Exception{
		//method now defunct - never worked properly
		
		//takes ipheader and icmpheader and creates and sends a NetworkMessage to the server
		//waits for response from server, then sends corresponding ip address from response back

		//procedure for sending data adapted from code in text page 172-3 "UDPClient.java"
		//make socket
		//make ipaddress
		//make byte array for send data 
		//make send data byte array equal to value from something that supports method getBytes();
		//make a DatagramPacket from send data 
		//call method send() on socket with constructed datagrampacket
		//
		//procedure for receiving data
		//create empty datagrampacket to "catch" data coming from socket
		//call method recieve() on socket, put recieved data into the packet just created
		//extract data by calling method getData on the datagrampacket now that it's been "filled"
		//close socket by calling method close()
		DatagramSocket mysocket = new DatagramSocket();
		//InetAddress serveraddress = InetAddress.getByName("192.168.51.117");
		NetworkMessage mymessage = new NetworkMessage();
		mymessage.icmpHdr=icmpheader;
		mymessage.ipHeader=ipheader;
		//byte[] messagebyte = mymessage.getBytes();
		//DatagramPacket mypacket = new DatagramPacket(messagebyte, 0, serveraddress, 3000);
		DatagramPacket mypacket = new DatagramPacket(mymessage.getBytes(), mymessage.getBytes().toString().length(), InetAddress.getByName("192.168.51.117"), 3000);
		mysocket.send(mypacket);
		byte[] recievemessage=new byte[mymessage.getBytes().toString().length()];
		DatagramPacket serverpacket = new DatagramPacket(recievemessage,recievemessage.toString().length());
		mysocket.receive(serverpacket);
		NetworkMessage servernetworkmessage = new NetworkMessage();
		servernetworkmessage.set(serverpacket.getData());
		mysocket.close();
		//return servernetworkmessage;
		IcmpHdr responseicmp = servernetworkmessage.icmpHdr;
		IPheader responseip = servernetworkmessage.ipHeader;
		String responseipstring = ((Integer)responseip.saddr).toString();
		InetAddress returndata = InetAddress.getByName(responseipstring);
		return returndata;
	}
}