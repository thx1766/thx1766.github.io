package traceroutestandard;

/*
* Definitions for internet protocol version 4.
* Per RFC 791, September 1981.
*
* 0       4       8               16      20      24            31
* +-------+-------+---------------+-------------------------------+
* | Vers  |Length |Type Of Service| Total Length                  |
* +-------+-------+---------------+-------+-----------------------+
* | Identification                | Flags | Fragment Offset Field |
* +---------------+---------------+-------+-----------------------+
* | Time To Live  | Protocol      | Header Checksum               |
* +---------------+---------------+-------------------------------+
* | Source Internet Address                                       |
* +---------------------------------------------------------------+
* | Destination Internet Address                                  |
* +---------------------------------------------------------------+
*/

public class IPheader {
	public byte	ihl;
	public byte	version;
	public byte	tos;
	public short	tot_len;
	public short	id;
	public byte	flags;
	public short	frag_off;
	public byte	ttl;
	public byte	protocol;
	public short	checksum;
	public int	saddr;
	public int	daddr;

	// protocols
	public final static int  IPPROTO_IP =            0;      /* dummy for IP */
	public final static int  IPPROTO_HOPOPTS =       0;      /* IPv6 hop-by-hop options */
	public final static int  IPPROTO_ICMP =          1;      /* control message protocol */
	public final static int  IPPROTO_IGMP =          2;      /* group control protocol */
	public final static int  IPPROTO_GGP =           3;      /* gateway^2 (deprecated) */
	public final static int  IPPROTO_IPIP =          4;      /* ip in ip encapsulation */
	public final static int  IPPROTO_TCP =           6;      /* tcp */
	public final static int  IPPROTO_EGP =           8;      /* exterior gateway protocol */
	public final static int  IPPROTO_PUP =           12;     /* pup */
	public final static int  IPPROTO_UDP =           17;     /* user datagram protocol */
	public final static int  IPPROTO_IDP =           22;     /* xns idp */
	public final static int  IPPROTO_TP =            29;     /* TP-4 w/ class negotiation */
	public final static int  IPPROTO_IPV6 =          41;     /* IPv6 in IPv4 or sockopt value */
	public final static int  IPPROTO_ROUTING =       43;     /* IPv6 routing header */
	public final static int  IPPROTO_FRAGMENT =      44;     /* IPv6 fragmentation header */
	public final static int  IPPROTO_ESP =           50;     /* encapsulation security payload */
	public final static int  IPPROTO_AH =            51;     /* authentication header */
	public final static int  IPPROTO_ICMPV6 =        58;     /* ICMPv6 */
	public final static int  IPPROTO_NONE =          59;     /* IPv6 no next header */
	public final static int  IPPROTO_DSTOPTS =       60;     /* IPv6 destination options */
	public final static int  IPPROTO_HELLO =         63;     /* hello routing protocol */
	public final static int  IPPROTO_ND =            77;     /* net disk proto, UNOFFICIAL */
	public final static int  IPPROTO_EON =           80;     /* ISO CLNP */
	public final static int  IPPROTO_RAW =           255;    /* raw IP packet */
	public final static int  IPPROTO_MAX =           256;

}