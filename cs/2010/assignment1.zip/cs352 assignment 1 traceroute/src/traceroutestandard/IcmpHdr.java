package traceroutestandard;

import java.io.*;

public class IcmpHdr {
	public byte	type;
	public byte	code;
	public short	checksum;
	public short	id;
	public short	sequence;

	// types and codes
	public final static int ICMP_ECHOREPLY = 0;
	public final static int ICMP_UNREACH = 3;       /* dest unreachable, codes: */
	public final static int         ICMP_UNREACH_NET =      0;       /* bad net */
	public final static int         ICMP_UNREACH_HOST =     1;      /* bad host */
	public final static int         ICMP_UNREACH_PROTOCOL = 2;      /* bad protocol */
	public final static int         ICMP_UNREACH_PORT =     3;      /* bad port */
	public final static int         ICMP_UNREACH_NEEDFRAG = 4;      /* IP_DF caused drop */
	public final static int         ICMP_UNREACH_SRCFAIL =  5;      /* src route failed */
	public final static int         ICMP_UNREACH_NET_UNKNOWN =      6;      /* dst net unknown */
	public final static int         ICMP_UNREACH_HOST_UNKNOWN =     7;      /* dst host unknown */
	public final static int         ICMP_UNREACH_ISOLATED = 8;      /* src host isolated */
	public final static int         ICMP_UNREACH_NET_PROHIB = 9;    /* com w/dst net admin prohib */
	public final static int         ICMP_UNREACH_HOST_PROHIB =      10;     /* com w/dst host admin prohib */
	public final static int         ICMP_UNREACH_TOSNET =   11;     /* net unreach for TOS */
	public final static int         ICMP_UNREACH_TOSHOST =  12;     /* host unreach for TOS */
	public final static int         ICMP_MAX_UNREACH =      12;     /* Max unreach value */
	public final static int ICMP_SOURCEQUENCH =     4;      /* packet lost, slow down */
	public final static int ICMP_REDIRECT =         5;      /* shorter route, codes: */
	public final static int         ICMP_REDIRECT_NET =     0;      /* for network */
	public final static int         ICMP_REDIRECT_HOST =    1;      /* for host */
	public final static int         ICMP_REDIRECT_TOSNET =  2;      /* for tos and net */
	public final static int ICMP_ECHO =             8;      /* echo service */
	public final static int ICMP_ROUTER_ADVERTISEMENT =     9;      /* router advertisement */
	public final static int         ICMP_ROUTERADVERT =     ICMP_ROUTER_ADVERTISEMENT;
	public final static int ICMP_ROUTER_SOLICITATION =      10;     /* router solicitation */
	public final static int         ICMP_ROUTERSOLICIT =    ICMP_ROUTER_SOLICITATION;
	public final static int ICMP_TIMXCEED =         11;     /* time exceeded, code: */
	public final static int         ICMP_TIMXCEED_INTRANS = 0;      /* ttl==0 in transit */
	public final static int         ICMP_TIMXCEED_REASS =   1;      /* ttl==0 in reass */
	public final static int ICMP_PARAMPROB =        12;     /* ip header bad */
	public final static int         ICMP_PARAMPROB_OPTABSENT = 1; /* required option is missing */
	public final static int ICMP_TSTAMP =           13;     /* timestamp request */
	public final static int ICMP_TSTAMPREPLY =      14;     /* timestamp reply */
	public final static int ICMP_IREQ =             15;     /* information request */
	public final static int ICMP_IREQREPLY =        16;     /* information reply */
	public final static int ICMP_MASKREQ =          17;     /* address mask request */
	public final static int ICMP_MASKREPLY =        18;     /* address mask reply */
	public final static int         ICMP_REDIRECT_TOSHOST = 3;      /* for tos and host */

	public byte [] getBytes() throws IOException
	{
		ByteArrayOutputStream	byteOutput = new ByteArrayOutputStream();
		ObjectOutputStream	objectOutput = new ObjectOutputStream( byteOutput );

		objectOutput.writeByte( type );
		objectOutput.writeByte( code );
		objectOutput.writeShort( checksum );
		objectOutput.writeShort( id );
		objectOutput.writeShort( sequence );
		objectOutput.close();
		return byteOutput.toString().getBytes();
	}

	public void set( byte [] byteArray ) throws IOException
	{
		ByteArrayInputStream	byteInput = new ByteArrayInputStream( byteArray );
		ObjectInputStream	objectInput = new ObjectInputStream( byteInput );

		type = objectInput.readByte();
		code = objectInput.readByte();
		checksum = objectInput.readShort();
		id = objectInput.readShort();
		sequence = objectInput.readShort();
		objectInput.close();
	}

	public static void main( String [] arg ) throws IOException
	{
		IcmpHdr			icmpHdr = new IcmpHdr();
		IcmpHdr			icmpHdr2 = new IcmpHdr();

		icmpHdr.type = ICMP_ECHO;
		icmpHdr.code = 0;
		icmpHdr.checksum = 1;
		icmpHdr.id = 2;
		icmpHdr.sequence = 3;

		icmpHdr2.set( icmpHdr.getBytes() );

		System.out.println( icmpHdr2.type );
		System.out.println( icmpHdr2.code );
		System.out.println( icmpHdr2.checksum );
		System.out.println( icmpHdr2.id );
		System.out.println( icmpHdr2.sequence );
	}
}